# Unity Sample Application
###Welcome to the Vungle Sample App for Unity!  
This repo includes a basic Unity application that showcases the various features available through the [Vungle Unity Plugin](https://v.vungle.com/dev/plugins).  
For a step-by-step walkthrough of how to get started using the Vungle Unity Plugin, check out our [Getting Started Guide](https://support.vungle.com/hc/en-us/articles/204311244).

For any other questions, feel free to reach out at https://support.vungle.com
